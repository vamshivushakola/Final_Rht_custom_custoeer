/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 5, 2014 11:07:58 AM                     ---
 * ----------------------------------------------------------------
 */
package com.hybris.addon.common.jalo;

import com.hybris.addon.common.constants.AddoncommonConstants;
import de.hybris.platform.jalo.extension.Extension;

/**
 * Generated class for type <code>AddoncommonManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedAddoncommonManager extends Extension
{
	@Override
	public String getName()
	{
		return AddoncommonConstants.EXTENSIONNAME;
	}
	
}
