/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 5, 2014 10:05:13 AM                     ---
 * ----------------------------------------------------------------
 */
package com.hybris.addon.common.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedAddoncommonConstants
{
	public static final String EXTENSIONNAME = "addoncommon";
	public static class TC
	{
		public static final String ABSTRACTMEDIACONTAINERCOMPONENT = "AbstractMediaContainerComponent".intern();
	}
	public static class Attributes
	{
		// no constants defined.
	}
	
	protected GeneratedAddoncommonConstants()
	{
		// private constructor
	}
	
	
}
