/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 5, 2014 11:07:58 AM                     ---
 * ----------------------------------------------------------------
 */
package com.hybris.vivocha.jalo;

import com.hybris.vivocha.constants.VivochaConstants;
import com.hybris.vivocha.jalo.CustomerSegmentVivochaComponent;
import com.hybris.vivocha.jalo.VivochaComponent;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import java.util.Map;

/**
 * Generated class for type <code>VivochaManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedVivochaManager extends Extension
{
	public CustomerSegmentVivochaComponent createCustomerSegmentVivochaComponent(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( VivochaConstants.TC.CUSTOMERSEGMENTVIVOCHACOMPONENT );
			return (CustomerSegmentVivochaComponent)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating CustomerSegmentVivochaComponent : "+e.getMessage(), 0 );
		}
	}
	
	public CustomerSegmentVivochaComponent createCustomerSegmentVivochaComponent(final Map attributeValues)
	{
		return createCustomerSegmentVivochaComponent( getSession().getSessionContext(), attributeValues );
	}
	
	public VivochaComponent createVivochaComponent(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( VivochaConstants.TC.VIVOCHACOMPONENT );
			return (VivochaComponent)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating VivochaComponent : "+e.getMessage(), 0 );
		}
	}
	
	public VivochaComponent createVivochaComponent(final Map attributeValues)
	{
		return createVivochaComponent( getSession().getSessionContext(), attributeValues );
	}
	
	@Override
	public String getName()
	{
		return VivochaConstants.EXTENSIONNAME;
	}
	
}
