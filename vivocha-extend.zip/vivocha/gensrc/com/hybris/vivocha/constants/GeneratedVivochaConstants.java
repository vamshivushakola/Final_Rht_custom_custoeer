/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 5, 2014 11:07:58 AM                     ---
 * ----------------------------------------------------------------
 */
package com.hybris.vivocha.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedVivochaConstants
{
	public static final String EXTENSIONNAME = "vivocha";
	public static class TC
	{
		public static final String CUSTOMERSEGMENTVIVOCHACOMPONENT = "CustomerSegmentVivochaComponent".intern();
		public static final String VIVOCHACOMPONENT = "VivochaComponent".intern();
	}
	public static class Attributes
	{
		// no constants defined.
	}
	
	protected GeneratedVivochaConstants()
	{
		// private constructor
	}
	
	
}
